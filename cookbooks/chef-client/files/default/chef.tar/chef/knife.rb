current_dir = File.dirname(__FILE__)
log_level                :info
log_location             STDOUT
node_name                "john"
client_key               "#{current_dir}/john.pem"
validation_client_name   "botchagalupe-validator"
validation_key           "#{current_dir}/botchagalupe-validator.pem"
chef_server_url          "https://api.opscode.com/organizations/botchagalupe"
cache_type               'BasicFile'
cache_options( :path => "#{ENV['HOME']}/.chef/checksums" )
cookbook_path            ["#{current_dir}/../cookbooks"]

knife[:aws_access_key_id] = ENV['AWS_ACCESS_KEY_ID']
knife[:aws_secret_access_key] = ENV['AWS_SECRET_ACCESS_KEY']

knife[:rackspace_api_username] = ENV['RS_API_USERNAME']
knife[:rackspace_api_key] = ENV['RS_API_KEY']


